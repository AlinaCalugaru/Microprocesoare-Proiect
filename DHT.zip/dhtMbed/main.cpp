#include "mbed.h"
#include "DHT.h"
// main() runs in its own thread in the OS
int main()
{

    DHT* a = new DHT(PTA12,DHT11);
    float h,t;
    int roundH, roundT;
    float x = 5.3;
    while (true) {


        a->readData();

        h = a->ReadHumidity();
        t = a->ReadTemperature(CELCIUS);

        roundH = (int)h;
        roundT = (int)t;



        printf("H:%d T:%d\n\r?",roundH,roundT);
       

        ThisThread::sleep_for(1000); 
    }
}

